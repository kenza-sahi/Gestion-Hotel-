package Noyau;

public class Erreur_indice_invalid extends Exception{

}
