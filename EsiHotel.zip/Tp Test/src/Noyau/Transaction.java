package Noyau;

import java.io.Serializable;

public enum Transaction implements Serializable {
    vente,location,echange,aucune

}