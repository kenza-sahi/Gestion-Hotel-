package Noyau;
public class Erreur_superficie extends Exception{
}
